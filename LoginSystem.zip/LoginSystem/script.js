function register() {
  const name = document.getElementById("regName").value;
  const email = document.getElementById("regEmail").value;
  const password = document.getElementById("regPassword").value;

  if (name && email && password) {
    const user = { name, email, password };
    localStorage.setItem("user", JSON.stringify(user));
    document.getElementById("message").innerText = "Registration successful!";
  } else {
    alert("Please fill in all fields.");
  }
}

function login() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const user = JSON.parse(localStorage.getItem("user"));

  if (user && email === user.email && password === user.password) {
    document.getElementById("message").innerText = `Welcome, ${user.name}!`;
  } else {
    document.getElementById("message").innerText = "Invalid credentials!";
  }
}
