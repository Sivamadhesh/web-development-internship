// Show fade-in effect when scrolling to About section
window.addEventListener("scroll", function () {
  const about = document.querySelector(".fade-in");
  const triggerBottom = window.innerHeight / 1.2;
  const aboutTop = about.getBoundingClientRect().top;

  if (aboutTop < triggerBottom) {
    about.classList.add("visible");
  }
});

// Page loaded message (optional)
console.log("Landing page loaded successfully!");
