// Register ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Animate each section when it scrolls into view
gsap.utils.toArray("section").forEach((sec) => {
  gsap.from(sec, {
    opacity: 0,
    y: 50,
    duration: 1,
    scrollTrigger: {
      trigger: sec,
      start: "top 80%", // animation starts when section top hits 80% of viewport
    },
  });
});
